package tv.alphanetworks.bee.lnv.mapping;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import tv.alphanetworks.bee.lnv.application.out.genius.dtos.ChampionshipDTO;
import tv.alphanetworks.bee.lnv.application.out.genius.dtos.CompetitionDTO;
import tv.alphanetworks.bee.lnv.application.out.genius.dtos.LegDTO;
import tv.alphanetworks.bee.lnv.application.out.genius.dtos.PhaseDTO;
import tv.alphanetworks.bee.lnv.application.out.genius.dtos.SeasonDTO;
import tv.alphanetworks.bee.lnv.application.out.genius.dtos.TeamDTO;
import tv.alphanetworks.bee.lnv.application.out.genius.dtos.TeamPlayerDTO;
import tv.alphanetworks.bee.lnv.application.out.genius.http.GeniusApiGateway;
import tv.alphanetworks.bee.lnv.application.out.kinow.dtos.ActorDTO;
import tv.alphanetworks.bee.lnv.application.out.kinow.dtos.CategoryDTO;
import tv.alphanetworks.bee.lnv.application.out.kinow.dtos.DirectorDTO;
import tv.alphanetworks.bee.lnv.application.out.kinow.dtos.ProductDTO;
import tv.alphanetworks.bee.lnv.application.out.kinow.webClient.WebClientKinowGateway;
import tv.alphanetworks.bee.lnv.domain.out.service.IngestService;

import java.text.ParseException;
import java.util.List;

@SpringBootTest
public class IngestServiceTest {
    @Autowired
    private IngestService ingestService;
    @Autowired
    private WebClientKinowGateway kinowGateway;
    @Autowired
    private GeniusApiGateway geniusApiGateway;

    @Test
    @DisplayName("Should Ingest Current Season")
    public void shouldIngestCurrentSeason() {
        CategoryDTO kinowSeason = ingestService.ingestCurrentSeason();
        Assertions.assertNotNull(kinowSeason);
    }

    @Test
    @DisplayName("Should Ingest Competitions Of Current Season")
    public void shouldIngestCompetitionsOfCurrentSeason() {
        CategoryDTO kinowSeason = ingestService.ingestCurrentSeason();
        List<CategoryDTO> kinowCompetitions = ingestService.ingestCompetitions(kinowSeason.getId());
        Assertions.assertFalse(kinowCompetitions.isEmpty());
    }

    @Test
    @DisplayName("Should Ingest Phases Of Competitions")
    public void shouldIngestPhasesOfCompetitions() {
        List<CompetitionDTO> geniusCompetitions = ingestService.getCompetitionsOfCurrentSeason(ingestService.getCurrentSeason(geniusApiGateway.getSeasons()).getSeasonID());
        List<CategoryDTO> kinowPhases = ingestService.ingestPhases(geniusCompetitions);
        Assertions.assertFalse(kinowPhases.isEmpty());
    }

    @Test
    @DisplayName("Should Ingest Championships Of Phases")
    public void shouldIngestChampionshipsOfPhases() {
        List<CompetitionDTO> geniusCompetitions = ingestService.getCompetitionsOfCurrentSeason(ingestService.getCurrentSeason(geniusApiGateway.getSeasons()).getSeasonID());
        List<List<PhaseDTO>> geniusPhases = ingestService.getPhasesOfAllCompetitions(geniusCompetitions);
        List<CategoryDTO> kinowChampionships = ingestService.ingestChampionships(geniusPhases);
        Assertions.assertFalse(kinowChampionships.isEmpty());
    }

    @Test
    @DisplayName("Should Ingest Legs Of Championships")
    public void shouldIngestLegsOfChampionships() {
        List<CompetitionDTO> geniusCompetitions = ingestService.getCompetitionsOfCurrentSeason(ingestService.getCurrentSeason(geniusApiGateway.getSeasons()).getSeasonID());
        List<List<PhaseDTO>> geniusPhases = ingestService.getPhasesOfAllCompetitions(geniusCompetitions);
        List<List<ChampionshipDTO>> geniusChampionships = ingestService.getChampionshipsOfAllPhases(geniusPhases);
        List<CategoryDTO> kinowLegs = ingestService.ingestLegs(geniusChampionships);
        Assertions.assertFalse(kinowLegs.isEmpty());
    }

    @Test
    @DisplayName("Should Ingest Matches Of Legs")
    public void shouldIngestMatchesOfLegs() throws ParseException {
        List<CompetitionDTO> geniusCompetitions = ingestService.getCompetitionsOfCurrentSeason(ingestService.getCurrentSeason(geniusApiGateway.getSeasons()).getSeasonID());
        List<List<PhaseDTO>> geniusPhases = ingestService.getPhasesOfAllCompetitions(geniusCompetitions);
        List<List<ChampionshipDTO>> geniusChampionships = ingestService.getChampionshipsOfAllPhases(geniusPhases);
        List<List<LegDTO>> geniusLegs = ingestService.getLegsOfAllChampionships(geniusChampionships);
        List<ProductDTO> kinowMatches = ingestService.ingestMatches(geniusLegs);
        Assertions.assertFalse(kinowMatches.isEmpty());
    }

    @Test
    @DisplayName("Should Ingest Clubs")
    public void shouldIngestClubs() {
        List<ActorDTO> kinowClubs = ingestService.ingestClubs();
        Assertions.assertFalse(kinowClubs.isEmpty());
    }

    @Test
    @DisplayName("Should Ingest Players Of Clubs")
    public void shouldIngestPlayersOfClubs() {
        List<TeamDTO> teamsOfCurrentSeason = ingestService.getTeamsOfCurrentSeason(ingestService.getCurrentSeason(geniusApiGateway.getSeasons()).getSeasonID());
        List<DirectorDTO> kinowPlayers = ingestService.ingestPlayers(teamsOfCurrentSeason);
        Assertions.assertFalse(kinowPlayers.isEmpty());
    }

    @Test
    @DisplayName("Should Delete All Categories")
    public void shouldDeleteAllCategories() {
        List<CategoryDTO> categories = ingestService.deleteCategoriesOfCategoryFromKinow();
        Assertions.assertTrue(categories.isEmpty());
    }

    @Test
    @DisplayName("Should Delete All Products")
    public void shouldDeleteAllProducts() {
        List<ProductDTO> products = ingestService.deleteAllProducts();
        Assertions.assertTrue(products.isEmpty());
    }

    @Test
    @DisplayName("Should Delete All Directors")
    public void shouldDeleteAllDirectors() {
        List<DirectorDTO> directors = ingestService.deleteAllDirectors();
        Assertions.assertTrue(directors.isEmpty());
    }

    @Test
    @DisplayName("Should Delete All Directors")
    public void shouldDeleteAllActors() {
        List<ActorDTO> actors = ingestService.deleteAllActors();
        Assertions.assertTrue(actors.isEmpty());
    }
}
