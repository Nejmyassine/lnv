package tv.alphanetworks.bee.lnv.kinow;

import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomStringUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.util.Assert;
import tv.alphanetworks.bee.lnv.application.out.kinow.KinowConfiguration;
import tv.alphanetworks.bee.lnv.application.out.kinow.dtos.ActorDTO;
import tv.alphanetworks.bee.lnv.application.out.kinow.dtos.CategoryDTO;
import tv.alphanetworks.bee.lnv.application.out.kinow.dtos.DirectorDTO;
import tv.alphanetworks.bee.lnv.application.out.kinow.dtos.LocalMetaData;
import tv.alphanetworks.bee.lnv.application.out.kinow.dtos.ProductDTO;
import tv.alphanetworks.bee.lnv.application.out.kinow.webClient.KinowWebClient;

import java.util.List;
import java.util.Random;

@Slf4j
@SpringBootTest
public class KinowWebClientTest {
    @Autowired
    KinowWebClient kinowWebClient;
    @Autowired
    KinowConfiguration kinowConfiguration;

    Random random = new Random();
    int testId = random.nextInt(10);
    String value = RandomStringUtils.randomAlphanumeric(15);

    @Test
    void create_actor_to_kinow_web_client() {
        ActorDTO actor = new ActorDTO(
                "Nikola KOVACEVIC",
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(1, RandomStringUtils.randomAlphanumeric(15))),
                true
        );
        ActorDTO actorToTest = kinowWebClient.createActor(actor).block();
        Assertions.assertNotNull(actorToTest);
    }

    @Test
    void create_category_to_kinow_web_client() throws JsonProcessingException {
        CategoryDTO category = new CategoryDTO(
                2L,
                true,
                List.of(new LocalMetaData(1, RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(1, RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15)))
        );
        CategoryDTO categoriesToTest = kinowWebClient.createCategory(category).block();
        Assertions.assertNotNull(categoriesToTest);
    }

    @Test
    void create_director_to_kinow_web_client() throws JsonProcessingException {
        DirectorDTO director = new DirectorDTO(
                1L,
                "Paris Volley",
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(1, RandomStringUtils.randomAlphanumeric(15))),
                true
        );
        DirectorDTO directorToTest = kinowWebClient.createDirector(director).block();
        Assertions.assertNotNull(directorToTest);
    }

    @Test
    void create_product_to_kinow_web_client() throws JsonProcessingException {
        ProductDTO product = new ProductDTO(1L,
                                            List.of(new LocalMetaData(1, RandomStringUtils.randomAlphanumeric(15))),
                                            List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                                            List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                                            List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                                            List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                                            List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                                            List.of(new LocalMetaData(1, RandomStringUtils.randomAlphanumeric(15))),
                                            true,
                                            1L
        );
        ProductDTO productToTest = kinowWebClient.createProduct(product).block();
        Assertions.assertNotNull(productToTest);
    }

    @Test
    void update_actor_to_kinow_web_client() {
        ActorDTO actorToCreate = new ActorDTO(
                "Nikola KOVACEVIC",
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(1, RandomStringUtils.randomAlphanumeric(15))),
                true
        );
        ActorDTO actorCreated = kinowWebClient.createActor(actorToCreate).block();
        ActorDTO actorToUpdate = new ActorDTO(
                "Nikola KOVACEVIC Updated",
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(1, RandomStringUtils.randomAlphanumeric(15))),
                false
        );
        ActorDTO actorUpdated = kinowWebClient.updateActor(actorToUpdate, actorCreated.getId()).block();
        Assertions.assertFalse(actorUpdated.isActive());
    }

    @Test
    void update_category_to_kinow_web_client() throws JsonProcessingException {
        CategoryDTO categoryToCreate = new CategoryDTO(
                2L,
                true,
                List.of(new LocalMetaData(1, RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(1, RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15)))
        );
        CategoryDTO categoryCreated = kinowWebClient.createCategory(categoryToCreate).block();
        CategoryDTO categoryToUpdate = new CategoryDTO(
                5L,
                true,
                List.of(new LocalMetaData(1, RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(1, RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15)))
        );
        CategoryDTO categoryUpdated = kinowWebClient.updateCategory(categoryToUpdate, categoryCreated.getId()).block();
        Assertions.assertNotNull(categoryUpdated);
    }

    @Test
    void update_director_to_kinow_web_client() {
        DirectorDTO directorToCreate = new DirectorDTO(
                1L,
                "Paris Volley",
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(1, RandomStringUtils.randomAlphanumeric(15))),
                true
        );
        DirectorDTO directorCreated = kinowWebClient.createDirector(directorToCreate).block();
        DirectorDTO directorToUpdate = new DirectorDTO(
                "Paris Volley updated",
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(1, RandomStringUtils.randomAlphanumeric(15))),
                false
        );
        DirectorDTO directorUpdated = kinowWebClient.updateDirector(directorToUpdate, directorCreated.getId()).block();
        Assertions.assertFalse(directorUpdated.isActive());
    }

    @Test
    void update_product_to_kinow_web_client() throws JsonProcessingException {
        ProductDTO productToCreate = new ProductDTO(
                List.of(new LocalMetaData(1, RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(1, RandomStringUtils.randomAlphanumeric(15))),
                true,
                2L
        );
        ProductDTO productCreated = kinowWebClient.createProduct(productToCreate).block();
        ProductDTO productToUpdate = new ProductDTO(
                List.of(new LocalMetaData(1, RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(new Random().nextInt(10), RandomStringUtils.randomAlphanumeric(15))),
                List.of(new LocalMetaData(1, RandomStringUtils.randomAlphanumeric(15))),
                false,
                2L
        );
        ProductDTO productUpdated = kinowWebClient.updateProduct(productToUpdate, productCreated.getId()).block();
        Assertions.assertFalse(productUpdated.isActive());
    }

    @Test
    void getCategories() {
        List <CategoryDTO> categoryDTOList = kinowWebClient.getCategories();
        LOGGER.info("KINOW : All Categories"+ categoryDTOList);
        Assertions.assertFalse(categoryDTOList.isEmpty());
    }

}