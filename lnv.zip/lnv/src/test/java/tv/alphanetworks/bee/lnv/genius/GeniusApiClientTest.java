package tv.alphanetworks.bee.lnv.genius;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import tv.alphanetworks.bee.lnv.application.out.genius.configuration.GeniusClientConfiguration;
import tv.alphanetworks.bee.lnv.application.out.genius.dtos.ChampionshipDTO;
import tv.alphanetworks.bee.lnv.application.out.genius.dtos.CompetitionDTO;
import tv.alphanetworks.bee.lnv.application.out.genius.dtos.LegDTO;
import tv.alphanetworks.bee.lnv.application.out.genius.dtos.MatchDTO;
import tv.alphanetworks.bee.lnv.application.out.genius.dtos.PhaseDTO;
import tv.alphanetworks.bee.lnv.application.out.genius.dtos.RefereeDTO;
import tv.alphanetworks.bee.lnv.application.out.genius.dtos.SeasonDTO;
import tv.alphanetworks.bee.lnv.application.out.genius.dtos.StadiumDTO;
import tv.alphanetworks.bee.lnv.application.out.genius.dtos.TeamDTO;
import tv.alphanetworks.bee.lnv.application.out.genius.dtos.TeamPlayerDTO;
import tv.alphanetworks.bee.lnv.application.out.genius.http.GeniusApiClient;

import java.util.Collections;
import java.util.List;
import java.util.Objects;

@Slf4j
@SpringBootTest
public class GeniusApiClientTest {

    @Autowired
    GeniusClientConfiguration geniusClientConfiguration;
    @Autowired
    private GeniusApiClient geniusApiClient;

    private GeniusApiClient.Token token;

    @BeforeEach
    void setup() {
        token = geniusApiClient.getAccessToken().block();
    }

    @Test
    void getAccessTokenTest() {
        if (token != null) {
            LOGGER.info(token.toString());
        }
        Assertions.assertNotNull(token);
    }

    @Test
    void getSeasons() {
        List<SeasonDTO> seasons = geniusApiClient.getSeasons(token.getAccessToken()).block();
        Assertions.assertNotEquals(Collections.EMPTY_LIST, seasons);
    }

    @Test
    void getCompetitionsOfSeason() {
        List<CompetitionDTO> competitions = geniusApiClient.getCompetitionsOfSeason(token.getAccessToken(), getSeasonId()).block();
        Assertions.assertNotEquals(Collections.EMPTY_LIST, competitions);
    }

    @Test
    void getPhasesOfCompetition() {
        List<PhaseDTO> phases = geniusApiClient.getPhasesOfCompetition(token.getAccessToken(), getCompetitionId()).block();
        Assertions.assertNotEquals(Collections.EMPTY_LIST, phases);
    }

    @Test
    void getChampionshipsOfPhase() {
        List<ChampionshipDTO> championships = geniusApiClient.getChampionshipsOfPhase(token.getAccessToken(), getPhaseId()).block();
        Assertions.assertNotEquals(Collections.EMPTY_LIST, championships);
    }

    @Test
    void getLegsOfChampionship() {
        List<LegDTO> legs = geniusApiClient.getLegsOfChampionship(token.getAccessToken(), getChampionshipId()).block();
        Assertions.assertNotEquals(Collections.EMPTY_LIST, legs);
    }

    @Test
    void getMatchesOfLeg() {
        List<MatchDTO> matches = geniusApiClient.getMatchesOfLeg(token.getAccessToken(), getLegId()).block();
        Assertions.assertNotEquals(Collections.EMPTY_LIST, matches);
    }

    @Test
    void getTeamsOfSeason() {
        List<TeamDTO> teams = geniusApiClient.getTeamsOfSeason(token.getAccessToken(), getSeasonId()).block();
        Assertions.assertNotEquals(Collections.EMPTY_LIST, teams);
    }

    @Test
    void getTeamPlayersOfTeam() {
        List<TeamPlayerDTO> teamPlayers = geniusApiClient.getTeamPlayersOfTeam(token.getAccessToken(), getTeamId()).block();
        Assertions.assertNotEquals(Collections.EMPTY_LIST, teamPlayers);
    }

    @Test
    void getStadiums() {
        List<StadiumDTO> stadiums = geniusApiClient.getStadiums(token.getAccessToken()).block();
        Assertions.assertNotEquals(Collections.EMPTY_LIST, stadiums);
    }

    @Test
    void getReferees() {
        List<RefereeDTO> referees = geniusApiClient.getReferees(token.getAccessToken()).block();
        Assertions.assertNotEquals(Collections.EMPTY_LIST, referees);
    }

    private Long getSeasonId() {
        return Objects.requireNonNull(geniusApiClient.getSeasons(token.getAccessToken()).block()).get(0).getSeasonID();
    }

    private Long getCompetitionId() {
        return Objects.requireNonNull(geniusApiClient.getCompetitionsOfSeason(token.getAccessToken(), getSeasonId()).block()).get(0).getCompetitionID();
    }

    private Long getPhaseId() {
        return Objects.requireNonNull(geniusApiClient.getPhasesOfCompetition(token.getAccessToken(), getCompetitionId()).block()).get(0).getPhaseID();
    }

    private Long getChampionshipId() {
        return Objects.requireNonNull(geniusApiClient.getChampionshipsOfPhase(token.getAccessToken(), getPhaseId()).block()).get(0).getChampionshipID();
    }

    private Long getLegId() {
        return Objects.requireNonNull(geniusApiClient.getLegsOfChampionship(token.getAccessToken(), getChampionshipId()).block()).get(0).getLegID();
    }

    private Long getTeamId() {
        return Objects.requireNonNull(geniusApiClient.getTeamsOfSeason(token.getAccessToken(), getSeasonId()).block()).get(0).getTeamID();
    }

}
